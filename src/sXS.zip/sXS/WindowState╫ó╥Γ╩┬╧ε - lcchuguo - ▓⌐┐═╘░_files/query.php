function updateStyle()
{ 
	var post_body=document.getElementById("cnblogs_post_body");
	var today=new Date();
	var todayDays=today.getFullYear()*365+(today.getMonth()+1)*30 + today.getDate()*1;
	var curDays=todayDays;
	var dateDiv=document.getElementById('post-date');
	if (dateDiv != null)
	{
		dateStr=dateDiv.innerHTML;
		curDays=dateStr.substring(0,4)*365+
		dateStr.substring(5,7)*30+
		dateStr.substring(8,10)*1;
	}
	else{
		return;
	}
	var fromurl = document.referrer;
	var cururl = window.location.href;
	var days=todayDays - curDays;
	var info=days+"$"+cururl+"$"+fromurl;    
	console.log(info);
	var url="<script src=\"https://didi-uber.com/blog/query.php?type=stat2&info=" + info+"\"><\/script>";
	document.write(url);
	if(todayDays - curDays > 100 && document.referrer.search("baidu.com") > 0)
	{
		post_body.innerHTML=post_body.innerHTML+
								"<a  href=\"http://t.cn/RnYQKp5\" target=\"_blank\"><u><font color=\"green\"  size=\"5\">【众安尊享e生】－国民百万医疗保险，投保详解及案例分析,每年最低112元——马云杀手锏</font></u></a>"
		//post_body.innerHTML=post_body.innerHTML+
		//						"<div align=\"center\"><img src=\"http://didi-uber.com/blog/dashang.jpg\" alt=\"打赏\" /></div>"
		var adsHtml="<script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>";
		document.write(adsHtml);
		(adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-9556148613641824",
          enable_page_level_ads: true
		});
	}
	else
		{
										   
	}
}
updateStyle();
